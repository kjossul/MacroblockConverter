import os
import json

def generate_item_map():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    result = {}

    for filename in os.listdir(script_dir):
        if filename.lower().endswith(".item.gbx"):
            # Strip .Item.Gbx extension (case-insensitive)
            block_name = filename[:-9]  # removes ".Item.Gbx" (9 chars)

            # Build the path after MacroConverter
            # Walk up to find the MacroConverter folder in the path
            parts = script_dir.replace("\\", "/").split("/")
            try:
                macro_idx = next(i for i, p in enumerate(parts) if p == "MacroblockConverter")
                relative_parts = parts[macro_idx + 1:]
                relative_path = "/".join(relative_parts + [filename])
            except StopIteration:
                # MacroConverter not found in path, just use filename
                print("[WARNING] 'MacroConverter' folder not found in script path. Using filename only.")
                relative_path = filename

            result[block_name] = relative_path

    output_path = os.path.join(script_dir, "item_map.json")
    with open(output_path, "w") as f:
        json.dump(result, f, indent=4)

    print(f"Done. {len(result)} item(s) mapped -> item_map.json")

if __name__ == "__main__":
    generate_item_map()